Hi!

All the up-to date information on the Defcon AI API can be found here:
http://www.introversion.co.uk/defcon/bots/index.html

Please refer to the documentation for info on how to get started. 
There's a quickstart guide for the impatient, so don't worry!


Download and Installation:

You'll need:
    * Windows demo: http://www.introversion.co.uk/defcon/
    * Bot-enabled Defcon executable and framework (the files that this readme 
      came with)

   1. Download and install the Windows demo version of DEFCON.
   2. Presumably you already unzipped the contents of the Defcon API zip file.
      Copy the contents of the zip file into the directory where you installed 
      Defcon, overwriting the original Defcon.exe (you can make a backup of that).
   3. Run Defcon.exe

Changelog:

===================
    v1.51 bot
17th November 2008
===================

Initial release
